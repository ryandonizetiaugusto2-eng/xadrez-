package com.exemplo.xadrezcoach

import android.content.Context
import android.graphics.*
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

class ArrowView(ctx: Context) : View(ctx) {
    private var text: String? = null
    private var a: PointF? = null
    private var b: PointF? = null
    private val d = ctx.resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC00E676.toInt(); strokeWidth = 12 * d; strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC00E676.toInt() }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6202020.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 17 * d }

    fun show(t: String?, from: PointF?, to: PointF?) { text = t; a = from; b = to; invalidate() }
    fun clear() = show(null, null, null)

    override fun onDraw(canvas: Canvas) {
        val pa = a; val pb = b
        if (pa != null && pb != null) {
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            canvas.save()
            canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
            val ang = Math.atan2((pb.y - pa.y).toDouble(), (pb.x - pa.x).toDouble())
            val hl = 34 * d
            val ex = (pb.x - hl * 0.6 * Math.cos(ang)).toFloat()
            val ey = (pb.y - hl * 0.6 * Math.sin(ang)).toFloat()
            canvas.drawLine(pa.x, pa.y, ex, ey, line)
            val p = Path()
            p.moveTo(pb.x, pb.y)
            p.lineTo((pb.x - hl * Math.cos(ang - 0.45)).toFloat(), (pb.y - hl * Math.sin(ang - 0.45)).toFloat())
            p.lineTo((pb.x - hl * Math.cos(ang + 0.45)).toFloat(), (pb.y - hl * Math.sin(ang + 0.45)).toFloat())
            p.close()
            canvas.drawPath(p, fill)
            canvas.drawCircle(pa.x, pa.y, 10 * d, fill)
            canvas.restore()
        }
        val t = text ?: return
        val w = (width - 32 * d).toInt()
        val lay = StaticLayout.Builder.obtain(t, 0, t.length, tp, w).build()
        canvas.save()
        canvas.translate(16 * d, 48 * d)
        canvas.drawRoundRect(-8 * d, -8 * d, w + 8 * d, lay.height + 8 * d, 12 * d, 12 * d, bg)
        lay.draw(canvas)
        canvas.restore()
    }
}
