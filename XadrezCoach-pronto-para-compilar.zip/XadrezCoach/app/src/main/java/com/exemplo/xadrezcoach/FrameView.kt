package com.exemplo.xadrezcoach

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/** Grade que o usuário alinha sobre o tabuleiro (arrastar = mover, pinça = tamanho). */
class FrameView(
    ctx: Context, start: IntArray?,
    private val onOk: (IntArray) -> Unit, private val onCancel: () -> Unit
) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private var l = start?.get(0)?.toFloat() ?: 0f
    private var t = start?.get(1)?.toFloat() ?: 0f
    private var s = start?.get(2)?.toFloat() ?: 0f
    private var lx = 0f
    private var ly = 0f
    private var hit = 0
    private val okR = RectF()
    private val noR = RectF()
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E676.toInt(); style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val grid = Paint().apply { color = 0x66FFFFFF; strokeWidth = 1 * d }
    private val b1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2D5A27.toInt() }
    private val b2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8B2E2E.toInt() }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 15 * d; textAlign = Paint.Align.CENTER; setShadowLayer(4 * d, 0f, 0f, Color.BLACK) }
    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(g: ScaleGestureDetector): Boolean {
            val cx = l + s / 2
            val cy = t + s / 2
            s = (s * g.scaleFactor).coerceIn(150f, width.toFloat())
            l = cx - s / 2; t = cy - s / 2
            invalidate()
            return true
        }
    })

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        if (s == 0f) { s = w * 0.94f; l = (w - s) / 2; t = h * 0.22f }
        val y = h - 150 * d
        okR.set(w / 2f - 170 * d, y, w / 2f - 10 * d, y + 56 * d)
        noR.set(w / 2f + 10 * d, y, w / 2f + 170 * d, y + 56 * d)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        if (e.pointerCount > 1) { lx = e.x; ly = e.y; return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y
                hit = if (okR.contains(e.x, e.y)) 1 else if (noR.contains(e.x, e.y)) 2 else 0
            }
            MotionEvent.ACTION_MOVE -> if (hit == 0) { l += e.x - lx; t += e.y - ly; lx = e.x; ly = e.y; invalidate() }
            MotionEvent.ACTION_UP -> {
                if (hit == 1 && okR.contains(e.x, e.y)) {
                    val loc = IntArray(2)
                    getLocationOnScreen(loc)
                    onOk(intArrayOf((l + loc[0]).toInt(), (t + loc[1]).toInt(), s.toInt()))
                } else if (hit == 2 && noR.contains(e.x, e.y)) onCancel()
                hit = 0
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(l, t, l + s, t + s, frame)
        for (i in 1..7) {
            c.drawLine(l + s * i / 8, t, l + s * i / 8, t + s, grid)
            c.drawLine(l, t + s * i / 8, l + s, t + s * i / 8, grid)
        }
        c.drawText("Alinhe a grade ao tabuleiro", width / 2f, 90 * d, hint)
        c.drawText("(arraste para mover, pinça para ajustar)", width / 2f, 112 * d, hint)
        c.drawText("A posição inicial deve estar visível", width / 2f, 134 * d, hint)
        c.drawRoundRect(okR, 16 * d, 16 * d, b1)
        c.drawRoundRect(noR, 16 * d, 16 * d, b2)
        c.drawText("✔ Fixar", okR.centerX(), okR.centerY() + 6 * d, hint)
        c.drawText("✕ Cancelar", noR.centerX(), noR.centerY() + 6 * d, hint)
    }
}
