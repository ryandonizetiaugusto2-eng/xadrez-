package com.exemplo.xadrezcoach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.abs

class CaptureService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var arrow: ArrowView
    private lateinit var bar: LinearLayout
    private lateinit var barLp: WindowManager.LayoutParams
    private lateinit var rec: Recognizer
    private var frame: FrameView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var busy = false
    private var sw = 0
    private var sh = 0
    private var token = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        rec = Recognizer(prefs)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupCapture(code, data)
        setupOverlay()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("xc", "Xadrez Coach", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "xc")
            .setContentTitle("Xadrez Coach ativo")
            .setContentText("Toque no ♞ flutuante para analisar")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(android.R.drawable.ic_delete, "Parar", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun setupCapture(code: Int, data: Intent) {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { stopSelf() } }
        }, ui)
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) synchronized(lock) { latest?.close(); latest = img }
        }, ui)
        vd = p.createVirtualDisplay(
            "xc", sw, sh, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(label: String, color: Int) = TextView(this).apply {
        text = label
        textSize = 22f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(4), 0, dp(4), 0) }
    }

    private fun setupOverlay() {
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        arrow = ArrowView(this)
        wm.addView(arrow, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
        ))
        val btn = circle("♞", 0xFF2D5A27.toInt())
        val cal = circle("⚙", 0xFF3A4A7A.toInt())
        val close = circle("✕", 0xFF8B2E2E.toInt())
        bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(btn); addView(cal); addView(close) }
        barLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(220) }
        wm.addView(bar, barLp)
        close.setOnClickListener { stopSelf() }
        cal.setOnClickListener { openFrame() }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = barLp.x; sy = barLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx
                    val my = e.rawY - dy
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) { barLp.x = sx + mx.toInt(); barLp.y = sy + my.toInt(); wm.updateViewLayout(bar, barLp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) analyze()
            }
            true
        }
        say(if (rec.ready) "Pronto. Na sua vez, toque no ♞." else "Comece na posição inicial e toque no ⚙ para calibrar.", null, null)
    }

    private fun say(t: String, a: PointF?, b: PointF?, ms: Long = 8000) {
        ui.post {
            arrow.show(t, a, b)
            val tk = ++token
            ui.postDelayed({ if (tk == token) arrow.clear() }, ms)
        }
    }

    private fun openFrame() {
        if (frame != null || busy) return
        arrow.clear()
        bar.visibility = View.GONE
        val f = FrameView(this, rec.rect, { r -> closeFrame(false); calibrate(r) }, { closeFrame(true) })
        frame = f
        wm.addView(f, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ))
    }

    private fun closeFrame(showBar: Boolean) {
        frame?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        frame = null
        if (showBar) bar.visibility = View.VISIBLE
    }

    private fun grab(): Bitmap? = synchronized(lock) { latest?.let { toBitmap(it) } }

    private fun calibrate(r: IntArray) {
        busy = true
        ui.postDelayed({ worker.execute {
            try {
                val bmp = grab() ?: throw Exception("Não consegui capturar a tela. Tente de novo.")
                val wb = prefs.getString("side", "w") == "w"
                if (!rec.calibrate(bmp, r, wb))
                    throw Exception("Calibração falhou. Deixe a posição inicial visível, com suas peças embaixo, e alinhe a grade ao tabuleiro.")
                say("Calibrado! Na sua vez, toque no ♞.", null, null)
            } catch (e: Exception) {
                say(e.message ?: "Erro", null, null)
            } finally {
                busy = false
                ui.post { bar.visibility = View.VISIBLE }
            }
        } }, 400)
    }

    private fun analyze() {
        if (busy || frame != null) return
        val wb = prefs.getString("side", "w") == "w"
        if (!rec.ready) { say("Primeiro toque no ⚙ e calibre com a posição inicial.", null, null); return }
        if (rec.calWb != wb) { say("Você mudou de lado. Recalibre no ⚙.", null, null); return }
        busy = true
        token++
        arrow.clear()
        bar.visibility = View.INVISIBLE
        ui.postDelayed({ worker.execute { run(wb) } }, 400)
    }

    private fun toBitmap(img: Image): Bitmap {
        val pl = img.planes[0]
        val pad = pl.rowStride - pl.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + pad / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(pl.buffer)
        return Bitmap.createBitmap(full, 0, 0, img.width, img.height)
    }

    private fun run(wb: Boolean) {
        try {
            val bmp = grab() ?: throw Exception("Não consegui capturar a tela. Tente de novo.")
            ui.post { bar.visibility = View.VISIBLE }
            val r = rec.rect!!
            val pl = rec.read(bmp, r, wb) ?: throw Exception("Não consegui ler o tabuleiro. Recalibre no ⚙.")
            if (!Engine.valid(pl)) throw Exception("Leitura inconsistente (reis). Deixe o tabuleiro visível ou recalibre no ⚙.")
            say("Calculando…", null, null, 30000)
            val sug = try { Engine.best(Engine.fen(pl, if (wb) "w" else "b"), prefs.getInt("depth", 3)) }
                catch (e: Exception) { throw Exception("Posição inválida lida da tela.") }
                ?: throw Exception("Sem jogadas legais nessa posição.")
            val cw = r[2] / 8f
            fun pt(sq: String): PointF {
                val f = sq[0] - 'a'
                val rk = sq[1] - '1'
                val col = if (wb) f else 7 - f
                val row = if (wb) 7 - rk else rk
                return PointF(r[0] + (col + 0.5f) * cw, r[1] + (row + 0.5f) * cw)
            }
            say(sug.text, pt(sug.from), pt(sug.to), 12000)
        } catch (e: Exception) {
            say(e.message ?: "Erro desconhecido", null, null)
        } finally {
            busy = false
            ui.post { bar.visibility = View.VISIBLE }
        }
    }

    override fun onDestroy() {
        closeFrame(false)
        try { wm.removeView(bar) } catch (e: Exception) {}
        try { wm.removeView(arrow) } catch (e: Exception) {}
        synchronized(lock) { latest?.close(); latest = null }
        vd?.release(); reader?.close()
        try { projection?.stop() } catch (e: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }
}
