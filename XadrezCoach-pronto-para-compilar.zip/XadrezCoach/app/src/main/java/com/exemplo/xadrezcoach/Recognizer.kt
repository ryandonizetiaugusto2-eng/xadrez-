package com.exemplo.xadrezcoach

import android.content.SharedPreferences
import android.graphics.Bitmap
import kotlin.math.abs

/** Lê o tabuleiro comparando silhuetas das peças com modelos aprendidos na posição inicial. */
class Recognizer(private val prefs: SharedPreferences) {
    class Tpl(val type: Char, val bits: BooleanArray)
    private class Cell(val bits: BooleanArray, val frac: Float, val lum: Float)

    private var tpls = listOf<Tpl>()
    private var lumW = 0f
    private var lumB = 0f
    var rect: IntArray? = null
    var calWb = true
    val ready: Boolean get() = tpls.isNotEmpty() && rect != null

    init {
        try {
            val t = prefs.getString("tpl", "") ?: ""
            if (t.isNotEmpty()) tpls = t.split(";").map { s -> Tpl(s[0], BooleanArray(144) { s[it + 1] == '1' }) }
            lumW = prefs.getFloat("lw", 0f)
            lumB = prefs.getFloat("lb", 0f)
            prefs.getString("rect", null)?.let { rect = it.split(",").map { x -> x.toInt() }.toIntArray() }
            calWb = prefs.getBoolean("cw", true)
        } catch (e: Exception) { tpls = listOf() }
    }

    private fun cell(bmp: Bitmap, x0: Int, y0: Int, w: Int): Cell {
        val sq = Bitmap.createBitmap(bmp, x0, y0, w, w)
        val s = Bitmap.createScaledBitmap(sq, 24, 24, true)
        val px = IntArray(576)
        s.getPixels(px, 0, 24, 0, 0, 24, 24)
        val idx = intArrayOf(25, 46, 529, 550)
        fun med(sh: Int): Int {
            val v = idx.map { (px[it] shr sh) and 255 }.sorted()
            return (v[1] + v[2]) / 2
        }
        val br = med(16); val bg = med(8); val bb = med(0)
        val m = BooleanArray(576)
        var n = 0
        var ls = 0f
        for (i in 0 until 576) {
            val p = px[i]
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (maxOf(abs(r - br), abs(g - bg), abs(b - bb)) > 32) {
                m[i] = true; n++; ls += 0.3f * r + 0.59f * g + 0.11f * b
            }
        }
        val bits = BooleanArray(144)
        for (y in 0 until 12) for (x in 0 until 12) {
            var c = 0
            for (dy in 0..1) for (dx in 0..1) if (m[(y * 2 + dy) * 24 + x * 2 + dx]) c++
            bits[y * 12 + x] = c >= 2
        }
        return Cell(bits, n / 576f, if (n > 0) ls / n else 0f)
    }

    private fun initial(f: Int, rk: Int): Char? = when (rk) {
        0 -> "RNBQKBNR"[f]
        1 -> 'P'
        6 -> 'p'
        7 -> "rnbqkbnr"[f]
        else -> null
    }

    private fun inside(bmp: Bitmap, r: IntArray) =
        r[2] >= 160 && r[0] >= 0 && r[1] >= 0 && r[0] + r[2] <= bmp.width && r[1] + r[2] <= bmp.height

    fun calibrate(bmp: Bitmap, r: IntArray, wb: Boolean): Boolean {
        if (!inside(bmp, r)) return false
        val w = r[2] / 8
        val list = mutableListOf<Tpl>()
        var sw = 0f; var cw = 0; var sb = 0f; var cb = 0
        for (row in 0..7) for (col in 0..7) {
            val f = if (wb) col else 7 - col
            val rk = if (wb) 7 - row else row
            val ch = initial(f, rk) ?: continue
            val c = cell(bmp, r[0] + col * w, r[1] + row * w, w)
            if (c.frac < 0.08f) return false
            list.add(Tpl(ch.uppercaseChar(), c.bits))
            if (ch.isUpperCase()) { sw += c.lum; cw++ } else { sb += c.lum; cb++ }
        }
        val lw = sw / cw; val lb = sb / cb
        if (lw - lb < 15f) return false
        tpls = list; lumW = lw; lumB = lb; rect = r; calWb = wb
        prefs.edit()
            .putString("tpl", list.joinToString(";") { t -> "${t.type}${t.bits.joinToString("") { b -> if (b) "1" else "0" }}" })
            .putFloat("lw", lw).putFloat("lb", lb)
            .putString("rect", r.joinToString(","))
            .putBoolean("cw", wb).apply()
        return true
    }

    /** Retorna o campo de posição do FEN ou null. */
    fun read(bmp: Bitmap, r: IntArray, wb: Boolean): String? {
        if (!ready || !inside(bmp, r)) return null
        val w = r[2] / 8
        val thr = (lumW + lumB) / 2
        val grid = Array(8) { CharArray(8) { '.' } }
        for (row in 0..7) for (col in 0..7) {
            val c = cell(bmp, r[0] + col * w, r[1] + row * w, w)
            if (c.frac < 0.12f) continue
            var best = 999
            var bt = 'P'
            for (t in tpls) {
                var d = 0
                for (i in 0 until 144) if (t.bits[i] != c.bits[i]) d++
                if (d < best) { best = d; bt = t.type }
            }
            if (best > 55) continue
            val f = if (wb) col else 7 - col
            val rk = if (wb) 7 - row else row
            grid[rk][f] = if (c.lum > thr) bt else bt.lowercaseChar()
        }
        val sb = StringBuilder()
        for (rk in 7 downTo 0) {
            var e = 0
            for (f in 0..7) {
                val ch = grid[rk][f]
                if (ch == '.') e++ else { if (e > 0) { sb.append(e); e = 0 }; sb.append(ch) }
            }
            if (e > 0) sb.append(e)
            if (rk > 0) sb.append('/')
        }
        return sb.toString()
    }
}
