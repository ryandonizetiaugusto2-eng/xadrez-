package com.exemplo.xadrezcoach

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val req = 42

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun radios(labels: List<String>, tags: List<Any>, selected: Int): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.HORIZONTAL
        labels.forEachIndexed { i, l ->
            val rb = RadioButton(this)
            rb.text = l
            rb.tag = tags[i]
            rb.id = i + 1
            g.addView(rb)
        }
        g.check(selected + 1)
        return g
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(40), dp(20), dp(20))

        fun label(t: String, size: Float = 14f) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, dp(12), 0, dp(4))
        }

        root.addView(label("♞ Xadrez Coach", 24f))

        root.addView(label("Eu jogo de"))
        val side = radios(listOf("Brancas", "Pretas"), listOf("w", "b"), if (p.getString("side", "w") == "b") 1 else 0)
        root.addView(side)

        root.addView(label("Força da análise"))
        val depth = radios(listOf("1", "2", "3", "4"), listOf(1, 2, 3, 4), p.getInt("depth", 3) - 1)
        root.addView(depth)

        val go = Button(this)
        go.text = "Iniciar"
        root.addView(go)
        val stop = Button(this)
        stop.text = "Parar"
        root.addView(stop)
        root.addView(label(
            "100% gratuito e offline. Como usar: toque em Iniciar e permita sobreposição e captura de tela. " +
            "Abra seu app de xadrez no INÍCIO de uma partida (posição inicial, suas peças embaixo), " +
            "toque no ⚙ flutuante, alinhe a grade ao tabuleiro (arraste e use pinça) e toque em Fixar. " +
            "Depois, na sua vez, toque no ♞: a melhor jogada aparece em texto e com uma seta. " +
            "Se mudar o tema das peças ou o tamanho do tabuleiro, calibre de novo. Use o celular na vertical."
        ))
        setContentView(ScrollView(this).apply { addView(root) })

        go.setOnClickListener {
            val sd = findViewById<RadioButton>(side.checkedRadioButtonId).tag as String
            val dp2 = findViewById<RadioButton>(depth.checkedRadioButtonId).tag as Int
            p.edit().putString("side", sd).putInt("depth", dp2).apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Ative “Sobrepor a outros apps” e toque em Iniciar de novo", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), req)
        }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)) }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == req && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Ativo! Abra seu app de xadrez.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
