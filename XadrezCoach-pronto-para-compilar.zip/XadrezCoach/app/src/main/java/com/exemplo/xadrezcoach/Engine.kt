package com.exemplo.xadrezcoach

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import kotlin.math.abs
import kotlin.random.Random

data class Suggestion(val from: String, val to: String, val text: String)

object Engine {
    private fun value(t: PieceType): Int = when (t) {
        PieceType.PAWN -> 100
        PieceType.KNIGHT -> 320
        PieceType.BISHOP -> 330
        PieceType.ROOK -> 500
        PieceType.QUEEN -> 900
        else -> 0
    }

    private fun eval(b: Board): Int {
        var s = 0
        for (sq in Square.values()) {
            if (sq == Square.NONE) continue
            val p = b.getPiece(sq)
            if (p == Piece.NONE) continue
            val t = p.pieceType
            val white = p.pieceSide == Side.WHITE
            val f = sq.file.ordinal
            val r = sq.rank.ordinal
            val ctr = 3.5 - maxOf(abs(f - 3.5), abs(r - 3.5))
            var v = value(t)
            when (t) {
                PieceType.KNIGHT, PieceType.BISHOP -> v += (ctr * 9).toInt()
                PieceType.QUEEN -> v += (ctr * 3).toInt()
                PieceType.PAWN -> {
                    val adv = if (white) r - 1 else 6 - r
                    v += adv * 6 + (if (f in 2..5) (ctr * 3).toInt() else 0)
                }
                PieceType.KING -> v -= abs(r - (if (white) 0 else 7)) * 12
                else -> {}
            }
            s += if (white) v else -v
        }
        return if (b.getSideToMove() == Side.WHITE) s else -s
    }

    private fun order(b: Board, ms: List<Move>): List<Move> = ms.sortedByDescending { m ->
        val victim = b.getPiece(m.to)
        var s = if (victim != Piece.NONE) 10 * value(victim.pieceType) - value(b.getPiece(m.from).pieceType) else 0
        if (m.promotion != Piece.NONE) s += 800
        s
    }

    private fun q(b: Board, a0: Int, beta: Int, qd: Int): Int {
        var a = a0
        val stand = eval(b)
        if (stand >= beta) return beta
        if (stand > a) a = stand
        if (qd == 0) return stand
        val caps = b.legalMoves().filter { b.getPiece(it.to) != Piece.NONE || it.promotion != Piece.NONE }
        for (m in order(b, caps)) {
            b.doMove(m)
            val sc = -q(b, -beta, -a, qd - 1)
            b.undoMove()
            if (sc >= beta) return beta
            if (sc > a) a = sc
        }
        return a
    }

    private fun nm(b: Board, d: Int, a0: Int, beta: Int, ply: Int): Int {
        var a = a0
        if (b.isDraw()) return 0
        val ms = b.legalMoves()
        if (ms.isEmpty()) return if (b.isKingAttacked()) -99999 + ply else 0
        if (d == 0) return q(b, a, beta, 4)
        for (m in order(b, ms)) {
            b.doMove(m)
            val sc = -nm(b, d - 1, -beta, -a, ply + 1)
            b.undoMove()
            if (sc >= beta) return beta
            if (sc > a) a = sc
        }
        return a
    }

    private fun dots(r: String) = buildString { for (c in r) if (c.isDigit()) repeat(c - '0') { append('.') } else append(c) }

    fun valid(pl: String): Boolean =
        pl.split("/").size == 8 && pl.count { it == 'K' } == 1 && pl.count { it == 'k' } == 1

    fun fen(pl: String, side: String): String {
        val rows = pl.split("/")
        val a = dots(rows[0]); val b = dots(rows[7])
        var c = ""
        if (b.length == 8 && b[4] == 'K') { if (b[7] == 'R') c += "K"; if (b[0] == 'R') c += "Q" }
        if (a.length == 8 && a[4] == 'k') { if (a[7] == 'r') c += "k"; if (a[0] == 'r') c += "q" }
        return "$pl $side ${if (c.isEmpty()) "-" else c} - 0 1"
    }

    fun best(fen: String, depth: Int): Suggestion? {
        val b = Board()
        b.loadFromFen(fen)
        var bestM: Move? = null
        var bs = Int.MIN_VALUE
        for (m in order(b, b.legalMoves())) {
            b.doMove(m)
            val sc = -nm(b, depth - 1, -1_000_000, 1_000_000, 1) + Random.nextInt(4)
            b.undoMove()
            if (sc > bs) { bs = sc; bestM = m }
        }
        val m = bestM ?: return null
        val pt = b.getPiece(m.from).pieceType
        val nome = when (pt) {
            PieceType.PAWN -> "Peão"
            PieceType.KNIGHT -> "Cavalo"
            PieceType.BISHOP -> "Bispo"
            PieceType.ROOK -> "Torre"
            PieceType.QUEEN -> "Dama"
            else -> "Rei"
        }
        val from = m.from.value().lowercase()
        val to = m.to.value().lowercase()
        val roque = pt == PieceType.KING && abs(m.to.file.ordinal - m.from.file.ordinal) == 2
        return Suggestion(from, to, "Melhor jogada: $nome $from → $to" + if (roque) " (roque)" else "")
    }
}
