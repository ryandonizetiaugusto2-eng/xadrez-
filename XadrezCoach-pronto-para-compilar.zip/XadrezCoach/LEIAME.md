# Xadrez Coach (Android) - gratuito e offline

Botões flutuantes: ♞ analisa, ⚙ calibra, ✕ fecha. Sem chave de API e sem internet.

## Gerar o APK
1. Instale o Android Studio. File > Open e escolha esta pasta; aguarde o Gradle Sync (precisa de internet só nessa hora).
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Arquivo: app/build/outputs/apk/debug/app-debug.apk. Instale no celular.

## Uso
1. Abra o app, escolha seu lado e a força, toque Iniciar e aceite as permissões.
2. Abra o app de xadrez e comece uma partida (posição inicial, suas peças embaixo).
3. Toque no ⚙, alinhe a grade verde ao tabuleiro e toque Fixar (o app aprende o desenho das peças).
4. Na sua vez, toque no ♞. Recalibre se mudar tema/tamanho do tabuleiro.
